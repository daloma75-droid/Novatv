# Nova TV (Android, Kotlin + Jetpack Compose + Media3)
1. Abre la carpeta en Android Studio (Koala o superior) -> "Open".
2. Deja que Gradle sincronice (genera el wrapper solo).
3. Run en un móvil/emulador, o Build > Build APK(s).
