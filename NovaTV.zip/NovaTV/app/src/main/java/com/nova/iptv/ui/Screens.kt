package com.nova.iptv.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.nova.iptv.MainVm
import com.nova.iptv.PlayerActivity
import com.nova.iptv.data.*

fun play(ctx: Context, item: Item) {
    ctx.startActivity(Intent(ctx, PlayerActivity::class.java)
        .putExtra("url", item.url).putExtra("alt", item.altUrl).putExtra("title", item.name))
}

private fun normHost(h: String): String {
    var x = h.trim().trimEnd('/')
    if (!x.startsWith("http://") && !x.startsWith("https://")) x = "http://$x"
    return x
}

// ------------------------------------------------------------ LOGIN
@Composable
fun LoginScreen(vm: MainVm) {
    val ctx = LocalContext.current
    var mode by remember { mutableIntStateOf(0) }
    var host by remember { mutableStateOf("") }
    var user by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var url by remember { mutableStateOf("") }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            runCatching { ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            vm.connect(Source.M3u(uri.toString()))
        }
    }
    Box(
        Modifier.fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF241552), Bg)))
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(Modifier.verticalScroll(rememberScrollState()), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("NOVA TV", fontSize = 40.sp, fontWeight = FontWeight.Black, color = Accent2)
            Text("Todo tu IPTV en un solo lugar", color = Color.Gray)
            Spacer(Modifier.height(24.dp))
            TabRow(selectedTabIndex = mode, containerColor = Color.Transparent) {
                Tab(mode == 0, { mode = 0 }) { Text("Xtream Codes", Modifier.padding(12.dp)) }
                Tab(mode == 1, { mode = 1 }) { Text("Lista M3U", Modifier.padding(12.dp)) }
            }
            Spacer(Modifier.height(16.dp))
            if (mode == 0) {
                Field(host, { host = it }, "Servidor (http://host:puerto)")
                Field(user, { user = it }, "Usuario")
                Field(pass, { pass = it }, "Contraseña", password = true)
                Spacer(Modifier.height(12.dp))
                Button(
                    onClick = { vm.connect(Source.Xtream(normHost(host), user.trim(), pass.trim())) },
                    enabled = host.isNotBlank() && user.isNotBlank(),
                    modifier = Modifier.fillMaxWidth().height(52.dp)
                ) { Text("Conectar") }
            } else {
                Field(url, { url = it }, "URL de la lista M3U")
                Spacer(Modifier.height(12.dp))
                Button(
                    onClick = { vm.connect(Source.M3u(url.trim())) },
                    enabled = url.isNotBlank(),
                    modifier = Modifier.fillMaxWidth().height(52.dp)
                ) { Text("Cargar lista") }
                TextButton(onClick = { picker.launch(arrayOf("*/*")) }) { Text("o elegir archivo del teléfono") }
            }
            vm.error?.let { Text(it, color = Color(0xFFFF6B6B), modifier = Modifier.padding(top = 12.dp)) }
        }
    }
}

@Composable
private fun Field(v: String, onChange: (String) -> Unit, label: String, password: Boolean = false) {
    OutlinedTextField(
        value = v, onValueChange = onChange, label = { Text(label) }, singleLine = true,
        visualTransformation = if (password) PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None,
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        shape = RoundedCornerShape(14.dp)
    )
}

// ------------------------------------------------------------ MAIN
@Composable
fun MainScreen(vm: MainVm) {
    var tab by remember { mutableIntStateOf(0) }
    val tabs = listOf("📺" to "En vivo", "🎬" to "Películas", "🍿" to "Series", "⚙️" to "Ajustes")
    Scaffold(
        containerColor = Bg,
        bottomBar = {
            NavigationBar(containerColor = Card) {
                tabs.forEachIndexed { i, (e, l) ->
                    NavigationBarItem(
                        selected = tab == i, onClick = { tab = i },
                        icon = { Text(e, fontSize = 20.sp) }, label = { Text(l, fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(indicatorColor = Accent.copy(alpha = .35f))
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> Browse(vm, Type.LIVE)
                1 -> Browse(vm, Type.MOVIE)
                2 -> Browse(vm, Type.SERIES)
                else -> SettingsScreen(vm)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Browse(vm: MainVm, type: Type) {
    val ctx = LocalContext.current
    val lib = vm.lib(type)
    var cat by remember(type) { mutableStateOf<Category?>(null) }
    var query by remember(type) { mutableStateOf("") }
    var pinFor by remember { mutableStateOf<Category?>(null) }

    val lockedIds = lib.cats.filter { vm.isLocked(type, it) }.map { it.id }.toSet()
    val visible = remember(lib, cat, query, lockedIds) {
        lib.items.filter {
            it.catId !in lockedIds &&
                (cat == null || it.catId == cat!!.id) &&
                (query.isBlank() || it.name.contains(query, true))
        }
    }

    Column(Modifier.fillMaxSize()) {
        OutlinedTextField(
            value = query, onValueChange = { query = it }, singleLine = true,
            placeholder = { Text("Buscar…") },
            leadingIcon = { Icon(Icons.Default.Search, null) },
            shape = RoundedCornerShape(24.dp),
            modifier = Modifier.fillMaxWidth().padding(12.dp, 12.dp, 12.dp, 4.dp)
        )
        LazyRow(contentPadding = PaddingValues(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            item { FilterChip(cat == null, { cat = null }, { Text("Todos") }) }
            items(lib.cats) { c ->
                val locked = c.id in lockedIds
                FilterChip(
                    selected = cat?.id == c.id,
                    onClick = { if (locked) pinFor = c else cat = c },
                    label = { Text((if (locked) "🔒 " else "") + c.name, maxLines = 1) }
                )
            }
        }
        Spacer(Modifier.height(8.dp))
        if (visible.isEmpty()) {
            Box(Modifier.fillMaxSize(), Alignment.Center) { Text("Sin resultados", color = Color.Gray) }
        } else if (type == Type.LIVE) {
            LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(visible) { ChannelRow(it) { play(ctx, it) } }
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Adaptive(110.dp), contentPadding = PaddingValues(12.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                gridItems(visible) { item ->
                    PosterCard(item) { if (item.seriesId != null) vm.openSeries(item) else play(ctx, item) }
                }
            }
        }
    }

    pinFor?.let { c ->
        PinDialog("Categoría protegida", { pinFor = null }) { pin ->
            if (vm.verifyPin(pin) || !vm.hasPin) {
                vm.unlocked.add(vm.key(type, c)); cat = c; pinFor = null; true
            } else false
        }
    }

    vm.episodesTitle?.let { title ->
        AlertDialog(
            onDismissRequest = { vm.closeEpisodes() },
            confirmButton = { TextButton({ vm.closeEpisodes() }) { Text("Cerrar") } },
            title = { Text(title, maxLines = 2, overflow = TextOverflow.Ellipsis) },
            text = {
                if (vm.episodes.isEmpty()) CircularProgressIndicator()
                else LazyColumn(Modifier.heightIn(max = 400.dp)) {
                    items(vm.episodes) { ep ->
                        Text(ep.name, Modifier.fillMaxWidth().clickable { play(ctx, ep) }.padding(vertical = 12.dp))
                        HorizontalDivider()
                    }
                }
            }
        )
    }
}

@Composable
fun ChannelRow(item: Item, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Card)
            .clickable(onClick = onClick).padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(56.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFF222B42)), Alignment.Center) {
            Text(item.name.take(1).uppercase(), color = Accent2, fontWeight = FontWeight.Bold)
            AsyncImage(item.logo, null, Modifier.fillMaxSize().padding(4.dp), contentScale = ContentScale.Fit)
        }
        Spacer(Modifier.width(12.dp))
        Text(item.name, Modifier.weight(1f), maxLines = 2, overflow = TextOverflow.Ellipsis)
        Icon(Icons.Default.PlayArrow, null, tint = Accent2)
    }
}

@Composable
fun PosterCard(item: Item, onClick: () -> Unit) {
    Box(
        Modifier.aspectRatio(2f / 3f).clip(RoundedCornerShape(14.dp)).background(Card).clickable(onClick = onClick)
    ) {
        AsyncImage(item.logo, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(listOf(Color.Transparent, Color(0xDD000000)), startY = 250f)
            )
        )
        item.rating?.takeIf { it.isNotBlank() && it != "0" }?.let {
            Text("★ $it", Modifier.align(Alignment.TopEnd).padding(6.dp).background(Color(0xAA000000), RoundedCornerShape(8.dp))
                .padding(horizontal = 6.dp, vertical = 2.dp), fontSize = 11.sp, color = Color(0xFFFFD54F))
        }
        Text(item.name, Modifier.align(Alignment.BottomStart).padding(8.dp), fontSize = 12.sp,
            maxLines = 2, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
    }
}

// ------------------------------------------------------------ PIN
@Composable
fun PinDialog(title: String, onDismiss: () -> Unit, onOk: (String) -> Boolean) {
    var pin by remember { mutableStateOf("") }
    var bad by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            OutlinedTextField(
                pin, { if (it.length <= 4 && it.all(Char::isDigit)) { pin = it; bad = false } },
                label = { Text("PIN de 4 dígitos") }, singleLine = true, isError = bad,
                supportingText = { if (bad) Text("PIN incorrecto") },
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword)
            )
        },
        confirmButton = { TextButton({ if (!onOk(pin)) bad = true }, enabled = pin.length == 4) { Text("Aceptar") } },
        dismissButton = { TextButton(onDismiss) { Text("Cancelar") } }
    )
}

// ------------------------------------------------------------ AJUSTES / CONTROL PARENTAL
@Composable
fun SettingsScreen(vm: MainVm) {
    var authed by remember { mutableStateOf(!vm.hasPin) }
    var askPin by remember { mutableStateOf(false) }
    var newPin by remember { mutableStateOf(false) }

    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item { Text("Control parental", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Accent2) }
        if (!authed) {
            item {
                Text("Introduce tu PIN para modificar el control parental.", color = Color.Gray)
                Button({ askPin = true }, Modifier.padding(top = 8.dp)) { Text("Introducir PIN") }
            }
        } else {
            item {
                Button({ newPin = true }) { Text(if (vm.hasPin) "Cambiar PIN" else "Crear PIN") }
            }
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Bloquear contenido adulto automáticamente")
                        Text("Detecta categorías como XXX, Adult, 18+", fontSize = 12.sp, color = Color.Gray)
                    }
                    Switch(vm.autoAdult, { vm.updateAutoAdult(it) })
                }
            }
            item { Text("Categorías bloqueadas con PIN", fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 8.dp)) }
            listOf(Type.LIVE to "En vivo", Type.MOVIE to "Películas", Type.SERIES to "Series").forEach { (t, label) ->
                item { Text(label, color = Accent2, modifier = Modifier.padding(top = 8.dp)) }
                items(vm.lib(t).cats) { c ->
                    val k = vm.key(t, c)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(k in vm.lockedCats, { vm.setLocked(k, it) })
                        Text(c.name, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
        }
        item {
            HorizontalDivider(Modifier.padding(vertical = 16.dp))
            OutlinedButton({ vm.logout() }, Modifier.fillMaxWidth()) { Text("Cerrar sesión / cambiar lista") }
        }
    }

    if (askPin) PinDialog("Introduce tu PIN", { askPin = false }) { if (vm.verifyPin(it)) { authed = true; askPin = false; true } else false }
    if (newPin) PinDialog("Nuevo PIN", { newPin = false }) { vm.setPin(it); newPin = false; true }
}
