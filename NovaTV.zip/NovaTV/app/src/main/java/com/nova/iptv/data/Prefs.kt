package com.nova.iptv.data

import android.content.Context
import org.json.JSONObject
import java.security.MessageDigest

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("nova", Context.MODE_PRIVATE)

    fun saveSource(s: Source?) {
        val e = sp.edit()
        when (s) {
            is Source.Xtream -> e.putString("src", JSONObject().put("t", "x").put("h", s.host)
                .put("u", s.user).put("p", s.pass).toString())
            is Source.M3u -> e.putString("src", JSONObject().put("t", "m").put("url", s.url).toString())
            null -> e.remove("src")
        }
        e.apply()
    }

    fun loadSource(): Source? {
        val j = sp.getString("src", null)?.let { JSONObject(it) } ?: return null
        return if (j.getString("t") == "x") Source.Xtream(j.getString("h"), j.getString("u"), j.getString("p"))
        else Source.M3u(j.getString("url"))
    }

    // ----- Control parental -----
    private fun hash(pin: String) = MessageDigest.getInstance("SHA-256")
        .digest(("nova$pin").toByteArray()).joinToString("") { "%02x".format(it) }

    val hasPin get() = sp.getString("pin", null) != null
    fun setPin(pin: String) = sp.edit().putString("pin", hash(pin)).apply()
    fun checkPin(pin: String) = sp.getString("pin", null) == hash(pin)

    var lockedCats: Set<String>
        get() = sp.getStringSet("locked", emptySet()) ?: emptySet()
        set(v) = sp.edit().putStringSet("locked", v).apply()

    var autoAdult: Boolean
        get() = sp.getBoolean("autoAdult", true)
        set(v) = sp.edit().putBoolean("autoAdult", v).apply()
}
