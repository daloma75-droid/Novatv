package com.nova.iptv

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.nova.iptv.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainVm(private val app: Application) : AndroidViewModel(app) {
    val prefs = Prefs(app)
    var source by mutableStateOf<Source?>(null)
    var loading by mutableStateOf(false)
    var error by mutableStateOf<String?>(null)
    var live by mutableStateOf(Library())
    var movies by mutableStateOf(Library())
    var series by mutableStateOf(Library())

    // Parental
    val unlocked = mutableStateListOf<String>()           // categorías desbloqueadas en esta sesión
    var lockedCats by mutableStateOf(prefs.lockedCats)
    var autoAdult by mutableStateOf(prefs.autoAdult)
    var hasPin by mutableStateOf(prefs.hasPin)

    // Episodios
    var episodesTitle by mutableStateOf<String?>(null)
    var episodes by mutableStateOf<List<Item>>(emptyList())

    private val adult = Regex("(?i)(xxx|adult|porn|18\\+|er[oó]tic|\\bsex)")

    init { prefs.loadSource()?.let { connect(it) } }

    fun lib(t: Type) = when (t) { Type.LIVE -> live; Type.MOVIE -> movies; Type.SERIES -> series }
    fun key(t: Type, c: Category) = "${t.name}:${c.id}"

    fun isLocked(t: Type, c: Category): Boolean {
        val k = key(t, c)
        val locked = k in lockedCats || (autoAdult && adult.containsMatchIn(c.name))
        return locked && k !in unlocked
    }

    fun connect(s: Source) {
        loading = true; error = null
        viewModelScope.launch {
            try {
                val (l, m, se) = withContext(Dispatchers.IO) { Repo.load(app, s) }
                live = l; movies = m; series = se; source = s
                prefs.saveSource(s)
            } catch (e: Exception) {
                error = e.message ?: "No se pudo conectar"
            }
            loading = false
        }
    }

    fun logout() {
        prefs.saveSource(null); source = null
        live = Library(); movies = Library(); series = Library(); unlocked.clear()
    }

    fun openSeries(item: Item) {
        val s = source as? Source.Xtream ?: return
        val id = item.seriesId ?: return
        episodesTitle = item.name; episodes = emptyList()
        viewModelScope.launch {
            episodes = try { withContext(Dispatchers.IO) { Repo.episodes(s, id) } } catch (e: Exception) { emptyList() }
        }
    }

    fun closeEpisodes() { episodesTitle = null }

    fun verifyPin(pin: String) = prefs.checkPin(pin)
    fun setPin(pin: String) { prefs.setPin(pin); hasPin = true }
    fun setLocked(k: String, on: Boolean) {
        lockedCats = if (on) lockedCats + k else lockedCats - k
        prefs.lockedCats = lockedCats
    }
    fun setAutoAdult(v: Boolean) { autoAdult = v; prefs.autoAdult = v }
}
