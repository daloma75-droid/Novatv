package com.nova.iptv.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Bg = Color(0xFF0B0F1A)
val Card = Color(0xFF151B2B)
val Accent = Color(0xFF7C4DFF)
val Accent2 = Color(0xFF00E5FF)

@Composable
fun NovaTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Accent, secondary = Accent2, background = Bg, surface = Card,
            onBackground = Color.White, onSurface = Color.White
        ),
        content = content
    )
}
