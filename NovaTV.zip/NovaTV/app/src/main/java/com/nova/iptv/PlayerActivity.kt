package com.nova.iptv

import android.content.pm.ActivityInfo
import android.net.Uri
import android.os.Bundle
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView
import com.nova.iptv.data.Repo
import kotlinx.coroutines.delay
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer as VlcPlayer
import org.videolan.libvlc.util.VLCVideoLayout

class PlayerActivity : ComponentActivity() {
    private var exo: ExoPlayer? = null
    private var lib: LibVLC? = null
    private var vlcRef: VlcPlayer? = null
    private var vlcState by mutableStateOf<VlcPlayer?>(null)
    private var useVlc by mutableStateOf(false)
    private var triedAlt = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }

        val url = intent.getStringExtra("url") ?: return finish()
        val alt = intent.getStringExtra("alt")
        val title = intent.getStringExtra("title") ?: ""
        useVlc = intent.getBooleanExtra("vlc", false)

        if (!useVlc) startExo(url, alt)

        setContent {
            Box(Modifier.fillMaxSize().background(Color.Black)) {
                if (useVlc) {
                    AndroidView(
                        factory = { ctx -> VLCVideoLayout(ctx).also { startVlc(it, url) } },
                        modifier = Modifier.fillMaxSize()
                    )
                    vlcState?.let { VlcControls(it, Modifier.align(Alignment.BottomCenter)) }
                } else {
                    exo?.let { p ->
                        AndroidView(
                            factory = { ctx ->
                                PlayerView(ctx).apply {
                                    this.player = p
                                    useController = true
                                    setShowBuffering(PlayerView.SHOW_BUFFERING_ALWAYS)
                                }
                            },
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                }
                Text(title, color = Color.White, modifier = Modifier.align(Alignment.TopStart).padding(16.dp))
            }
        }
    }

    private fun startExo(url: String, alt: String?) {
        val ds = DefaultHttpDataSource.Factory().setUserAgent(Repo.UA).setAllowCrossProtocolRedirects(true)
        val p = ExoPlayer.Builder(this).setMediaSourceFactory(DefaultMediaSourceFactory(ds)).build()
        p.setMediaItem(MediaItem.fromUri(url))
        p.prepare()
        p.playWhenReady = true
        p.addListener(object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                if (!triedAlt && alt != null) {            // .m3u8 falló -> probar .ts
                    triedAlt = true
                    p.setMediaItem(MediaItem.fromUri(alt)); p.prepare(); p.play()
                } else {                                    // ExoPlayer no puede -> pasar a VLC
                    exo = null
                    p.release()
                    useVlc = true
                }
            }
        })
        exo = p
    }

    private fun startVlc(layout: VLCVideoLayout, url: String) {
        val args = arrayListOf("--network-caching=2500", "--http-user-agent=${Repo.UA}", "--http-reconnect")
        val l = LibVLC(this, args)
        val mp = VlcPlayer(l)
        mp.attachViews(layout, null, false, false)
        val media = Media(l, Uri.parse(url))
        mp.media = media
        media.release()
        mp.setEventListener { e ->
            if (e.type == VlcPlayer.Event.EncounteredError)
                Toast.makeText(this, "No se pudo reproducir este contenido", Toast.LENGTH_LONG).show()
        }
        mp.play()
        lib = l; vlcRef = mp; vlcState = mp
    }

    override fun onStop() { super.onStop(); exo?.pause(); vlcRef?.pause() }

    override fun onDestroy() {
        exo?.release(); exo = null
        vlcRef?.let { it.stop(); it.detachViews(); it.release() }
        lib?.release()
        super.onDestroy()
    }
}

@Composable
private fun VlcControls(mp: VlcPlayer, modifier: Modifier = Modifier) {
    var pos by remember { mutableLongStateOf(0L) }
    var len by remember { mutableLongStateOf(0L) }
    var playing by remember { mutableStateOf(true) }
    LaunchedEffect(mp) {
        while (true) {
            pos = mp.time; len = mp.length; playing = mp.isPlaying
            delay(500)
        }
    }
    Row(
        modifier.fillMaxWidth().background(Color(0x99000000)).padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Button(onClick = { if (mp.isPlaying) mp.pause() else mp.play() }) { Text(if (playing) "⏸" else "▶") }
        if (len > 0) {
            Button(onClick = { mp.time = (mp.time - 10_000).coerceAtLeast(0) }, modifier = Modifier.padding(start = 6.dp)) { Text("−10s") }
            Slider(
                value = pos.toFloat(), onValueChange = { pos = it.toLong(); mp.time = it.toLong() },
                valueRange = 0f..len.toFloat(), modifier = Modifier.weight(1f).padding(horizontal = 8.dp)
            )
            Button(onClick = { mp.time = (mp.time + 10_000).coerceAtMost(len) }) { Text("+10s") }
        } else {
            Text("  EN VIVO", color = Color.White)
        }
    }
}
