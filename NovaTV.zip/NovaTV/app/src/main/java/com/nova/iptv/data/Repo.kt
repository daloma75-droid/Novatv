package com.nova.iptv.data

import android.content.Context
import android.net.Uri
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

/**
 * Igual que IPTV Smarters Pro, soporta dos formas de entrada:
 *  1) Xtream Codes API  -> host + usuario + contraseña (player_api.php)
 *  2) Lista M3U/M3U8    -> URL remota o archivo local
 */
object Repo {
    const val UA = "VLC/3.0.18 LibVLC/3.0.18" // muchos proveedores bloquean user-agents desconocidos

    private val http = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .build()

    private fun get(url: String): String {
        val req = Request.Builder().url(url).header("User-Agent", UA).build()
        http.newCall(req).execute().use { r ->
            if (!r.isSuccessful) error("Error HTTP ${r.code}")
            return r.body!!.string()
        }
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    // ---------- Xtream Codes ----------
    private fun api(s: Source.Xtream, action: String? = null, extra: String = ""): String {
        val a = if (action != null) "&action=$action" else ""
        return get("${s.host}/player_api.php?username=${enc(s.user)}&password=${enc(s.pass)}$a$extra")
    }

    private fun cats(json: String): List<Category> {
        val a = JSONArray(json)
        return (0 until a.length()).map {
            val o = a.getJSONObject(it)
            Category(o.optString("category_id"), o.optString("category_name"))
        }
    }

    private fun xtream(s: Source.Xtream): Triple<Library, Library, Library> {
        val info = JSONObject(api(s))
        val auth = info.optJSONObject("user_info")?.optInt("auth", 0) ?: 0
        if (auth != 1) error("Usuario o contraseña incorrectos")

        val live = runCatching {
            val a = JSONArray(api(s, "get_live_streams"))
            Library(cats(api(s, "get_live_categories")), (0 until a.length()).map {
                val o = a.getJSONObject(it)
                val id = o.optString("stream_id")
                val base = "${s.host}/live/${s.user}/${s.pass}/$id"
                Item(id, o.optString("name"), o.optString("stream_icon").ifBlank { null },
                    o.optString("category_id"), "$base.m3u8", Type.LIVE, altUrl = "$base.ts")
            })
        }.getOrDefault(Library())

        val movies = runCatching {
            val a = JSONArray(api(s, "get_vod_streams"))
            Library(cats(api(s, "get_vod_categories")), (0 until a.length()).map {
                val o = a.getJSONObject(it)
                val id = o.optString("stream_id")
                val ext = o.optString("container_extension", "mp4").ifBlank { "mp4" }
                Item(id, o.optString("name"), o.optString("stream_icon").ifBlank { null },
                    o.optString("category_id"), "${s.host}/movie/${s.user}/${s.pass}/$id.$ext",
                    Type.MOVIE, rating = o.optString("rating").ifBlank { null })
            })
        }.getOrDefault(Library())

        val series = runCatching {
            val a = JSONArray(api(s, "get_series"))
            Library(cats(api(s, "get_series_categories")), (0 until a.length()).map {
                val o = a.getJSONObject(it)
                val id = o.optString("series_id")
                Item(id, o.optString("name"), o.optString("cover").ifBlank { null },
                    o.optString("category_id"), "", Type.SERIES,
                    rating = o.optString("rating").ifBlank { null }, seriesId = id)
            })
        }.getOrDefault(Library())

        return Triple(live, movies, series)
    }

    fun episodes(s: Source.Xtream, seriesId: String): List<Item> {
        val root = JSONObject(api(s, "get_series_info", "&series_id=$seriesId"))
        val eps = root.optJSONObject("episodes") ?: return emptyList()
        val out = mutableListOf<Item>()
        eps.keys().asSequence().sortedBy { it.toIntOrNull() ?: 0 }.forEach { season ->
            val arr = eps.getJSONArray(season)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val id = o.optString("id")
                val ext = o.optString("container_extension", "mp4").ifBlank { "mp4" }
                out += Item(id, "T$season · E${o.optString("episode_num")}  ${o.optString("title")}",
                    o.optJSONObject("info")?.optString("movie_image")?.ifBlank { null },
                    season, "${s.host}/series/${s.user}/${s.pass}/$id.$ext", Type.SERIES)
            }
        }
        return out
    }

    // ---------- M3U ----------
    private val attr = Regex("""([\w-]+)="([^"]*)"""")
    private val movieHint = Regex("(?i)pel[ií]cula|movie|vod|cine|film")
    private val seriesHint = Regex("(?i)serie|temporada|season")

    fun parseM3u(text: String): Triple<Library, Library, Library> {
        val items = mutableListOf<Item>()
        var name = ""; var logo: String? = null; var group = "Sin categoría"
        var idx = 0
        for (line in text.lineSequence()) {
            val l = line.trim()
            if (l.startsWith("#EXTINF")) {
                val a = attr.findAll(l).associate { it.groupValues[1].lowercase() to it.groupValues[2] }
                name = l.substringAfterLast(",").trim().ifBlank { a["tvg-name"] ?: "Canal" }
                logo = a["tvg-logo"]?.ifBlank { null }
                group = a["group-title"]?.ifBlank { null } ?: "Sin categoría"
            } else if (l.isNotEmpty() && !l.startsWith("#")) {
                val clean = l.substringBefore('?').lowercase()
                val isFile = clean.endsWith(".mp4") || clean.endsWith(".mkv") || clean.endsWith(".avi")
                val type = when {
                    "/series/" in l || seriesHint.containsMatchIn(group) -> Type.SERIES
                    "/movie/" in l || movieHint.containsMatchIn(group) || isFile -> Type.MOVIE
                    else -> Type.LIVE
                }
                items += Item((idx++).toString(), name, logo, group, l, type)
                name = ""; logo = null
            }
        }
        fun lib(t: Type): Library {
            val list = items.filter { it.type == t }
            return Library(list.map { it.catId }.distinct().map { Category(it, it) }, list)
        }
        return Triple(lib(Type.LIVE), lib(Type.MOVIE), lib(Type.SERIES))
    }

    fun load(ctx: Context, s: Source): Triple<Library, Library, Library> {
        val r = when (s) {
            is Source.Xtream -> xtream(s)
            is Source.M3u -> {
                val text = if (s.url.startsWith("content://"))
                    ctx.contentResolver.openInputStream(Uri.parse(s.url))!!.bufferedReader().use { it.readText() }
                else get(s.url)
                if (!text.contains("#EXTM3U") && !text.contains("#EXTINF")) error("La lista no es un M3U válido")
                parseM3u(text)
            }
        }
        if (r.first.items.isEmpty() && r.second.items.isEmpty() && r.third.items.isEmpty())
            error("La lista está vacía o no se pudo leer")
        return r
    }
}
