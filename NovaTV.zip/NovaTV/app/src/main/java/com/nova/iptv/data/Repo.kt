package com.nova.iptv.data

import android.content.Context
import android.net.Uri
import android.util.JsonReader
import android.util.JsonToken
import java.io.InputStreamReader
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

/**
 * Igual que IPTV Smarters Pro, soporta dos formas de entrada:
 *  1) Xtream Codes API  -> host + usuario + contraseña (player_api.php)
 *  2) Lista M3U/M3U8    -> URL remota o archivo local
 */
object Repo {
    const val UA = "VLC/3.0.18 LibVLC/3.0.18" // muchos proveedores bloquean user-agents desconocidos

    private val http = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .build()

    private fun get(url: String): String {
        val req = Request.Builder().url(url).header("User-Agent", UA).build()
        http.newCall(req).execute().use { r ->
            if (!r.isSuccessful) error("Error HTTP ${r.code}")
            return r.body!!.string()
        }
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    // ---------- Xtream Codes ----------
    private fun api(s: Source.Xtream, action: String? = null, extra: String = ""): String {
        val a = if (action != null) "&action=$action" else ""
        return get("${s.host}/player_api.php?username=${enc(s.user)}&password=${enc(s.pass)}$a$extra")
    }

    val warnings = mutableMapOf<Type, String>()

    private fun cats(s: Source.Xtream, action: String): List<Category> = try {
        val a = JSONArray(api(s, action))
        (0 until a.length()).map {
            val o = a.getJSONObject(it)
            Category(o.optString("category_id"), o.optString("category_name"))
        }
    } catch (e: Throwable) { emptyList() }

    /** Lee un array JSON enorme objeto a objeto (el catálogo de VOD puede pesar decenas de MB). */
    private fun stream(url: String, keys: Set<String>, onObj: (Map<String, String>) -> Unit) {
        val req = Request.Builder().url(url).header("User-Agent", UA).build()
        http.newCall(req).execute().use { r ->
            if (!r.isSuccessful) error("Error HTTP ${r.code}")
            JsonReader(InputStreamReader(r.body!!.byteStream(), "UTF-8")).use { jr ->
                if (jr.peek() != JsonToken.BEGIN_ARRAY) { jr.skipValue(); return }
                jr.beginArray()
                while (jr.hasNext()) {
                    if (jr.peek() != JsonToken.BEGIN_OBJECT) { jr.skipValue(); continue }
                    val m = HashMap<String, String>()
                    jr.beginObject()
                    while (jr.hasNext()) {
                        val n = jr.nextName()
                        val t = jr.peek()
                        if (n in keys && (t == JsonToken.STRING || t == JsonToken.NUMBER)) m[n] = jr.nextString()
                        else jr.skipValue()
                    }
                    jr.endObject()
                    onObj(m)
                }
                jr.endArray()
            }
        }
    }

    private fun <T> section(t: Type, default: T, block: () -> T): T {
        var last: Throwable? = null
        repeat(2) {
            try { return block() } catch (e: Throwable) { last = e }
        }
        warnings[t] = last?.message ?: last?.javaClass?.simpleName ?: "error desconocido"
        return default
    }

    private fun xtream(s: Source.Xtream): Triple<Library, Library, Library> {
        warnings.clear()
        val info = JSONObject(api(s))
        val auth = info.optJSONObject("user_info")?.optInt("auth", 0) ?: 0
        if (auth != 1) error("Usuario o contraseña incorrectos")

        val live = section(Type.LIVE, Library()) {
            val items = ArrayList<Item>()
            stream(
                "${s.host}/player_api.php?username=${enc(s.user)}&password=${enc(s.pass)}&action=get_live_streams",
                setOf("stream_id", "name", "stream_icon", "category_id")
            ) { o ->
                val id = o["stream_id"] ?: return@stream
                val base = "${s.host}/live/${s.user}/${s.pass}/$id"
                items += Item(id, o["name"] ?: "Canal", o["stream_icon"]?.ifBlank { null },
                    o["category_id"] ?: "", "$base.m3u8", Type.LIVE, altUrl = "$base.ts")
            }
            Library(cats(s, "get_live_categories"), items)
        }

        val movies = section(Type.MOVIE, Library()) {
            val items = ArrayList<Item>()
            stream(
                "${s.host}/player_api.php?username=${enc(s.user)}&password=${enc(s.pass)}&action=get_vod_streams",
                setOf("stream_id", "name", "stream_icon", "category_id", "container_extension", "rating")
            ) { o ->
                val id = o["stream_id"] ?: return@stream
                val ext = (o["container_extension"] ?: "mp4").ifBlank { "mp4" }
                items += Item(id, o["name"] ?: "Película", o["stream_icon"]?.ifBlank { null },
                    o["category_id"] ?: "", "${s.host}/movie/${s.user}/${s.pass}/$id.$ext",
                    Type.MOVIE, rating = o["rating"]?.ifBlank { null })
            }
            Library(cats(s, "get_vod_categories"), items)
        }

        val series = section(Type.SERIES, Library()) {
            val items = ArrayList<Item>()
            stream(
                "${s.host}/player_api.php?username=${enc(s.user)}&password=${enc(s.pass)}&action=get_series",
                setOf("series_id", "name", "cover", "category_id", "rating")
            ) { o ->
                val id = o["series_id"] ?: return@stream
                items += Item(id, o["name"] ?: "Serie", o["cover"]?.ifBlank { null },
                    o["category_id"] ?: "", "", Type.SERIES,
                    rating = o["rating"]?.ifBlank { null }, seriesId = id)
            }
            Library(cats(s, "get_series_categories"), items)
        }

        return Triple(live, movies, series)
    }

    fun episodes(s: Source.Xtream, seriesId: String): List<Item> {
        val root = JSONObject(api(s, "get_series_info", "&series_id=$seriesId"))
        val eps = root.optJSONObject("episodes") ?: return emptyList()
        val out = mutableListOf<Item>()
        eps.keys().asSequence().sortedBy { it.toIntOrNull() ?: 0 }.forEach { season ->
            val arr = eps.getJSONArray(season)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val id = o.optString("id")
                val ext = o.optString("container_extension", "mp4").ifBlank { "mp4" }
                out += Item(id, "T$season · E${o.optString("episode_num")}  ${o.optString("title")}",
                    o.optJSONObject("info")?.optString("movie_image")?.ifBlank { null },
                    season, "${s.host}/series/${s.user}/${s.pass}/$id.$ext", Type.SERIES)
            }
        }
        return out
    }

    // ---------- M3U ----------
    private val attr = Regex("""([\w-]+)="([^"]*)"""")
    private val movieHint = Regex("(?i)pel[ií]cula|movie|vod|cine|film")
    private val seriesHint = Regex("(?i)serie|temporada|season")

    fun parseM3u(text: String): Triple<Library, Library, Library> {
        val items = mutableListOf<Item>()
        var name = ""; var logo: String? = null; var group = "Sin categoría"
        var idx = 0
        for (line in text.lineSequence()) {
            val l = line.trim()
            if (l.startsWith("#EXTINF")) {
                val a = attr.findAll(l).associate { it.groupValues[1].lowercase() to it.groupValues[2] }
                name = l.substringAfterLast(",").trim().ifBlank { a["tvg-name"] ?: "Canal" }
                logo = a["tvg-logo"]?.ifBlank { null }
                group = a["group-title"]?.ifBlank { null } ?: "Sin categoría"
            } else if (l.isNotEmpty() && !l.startsWith("#")) {
                val clean = l.substringBefore('?').lowercase()
                val isFile = clean.endsWith(".mp4") || clean.endsWith(".mkv") || clean.endsWith(".avi")
                val type = when {
                    "/series/" in l || seriesHint.containsMatchIn(group) -> Type.SERIES
                    "/movie/" in l || movieHint.containsMatchIn(group) || isFile -> Type.MOVIE
                    else -> Type.LIVE
                }
                items += Item((idx++).toString(), name, logo, group, l, type)
                name = ""; logo = null
            }
        }
        fun lib(t: Type): Library {
            val list = items.filter { it.type == t }
            return Library(list.map { it.catId }.distinct().map { Category(it, it) }, list)
        }
        return Triple(lib(Type.LIVE), lib(Type.MOVIE), lib(Type.SERIES))
    }

    fun load(ctx: Context, s: Source): Triple<Library, Library, Library> {
        val r = when (s) {
            is Source.Xtream -> xtream(s)
            is Source.M3u -> {
                val text = if (s.url.startsWith("content://"))
                    ctx.contentResolver.openInputStream(Uri.parse(s.url))!!.bufferedReader().use { it.readText() }
                else get(s.url)
                if (!text.contains("#EXTM3U") && !text.contains("#EXTINF")) error("La lista no es un M3U válido")
                parseM3u(text)
            }
        }
        if (r.first.items.isEmpty() && r.second.items.isEmpty() && r.third.items.isEmpty())
            error("La lista está vacía o no se pudo leer")
        return r
    }
}
