package com.nova.iptv.data

enum class Type { LIVE, MOVIE, SERIES }

data class Category(val id: String, val name: String)

data class Item(
    val id: String,
    val name: String,
    val logo: String?,
    val catId: String,
    val url: String,
    val type: Type,
    val rating: String? = null,
    val seriesId: String? = null,   // solo Xtream: al tocar se cargan los episodios
    val altUrl: String? = null      // alternativa (.ts) si falla el .m3u8
)

data class Library(val cats: List<Category> = emptyList(), val items: List<Item> = emptyList())

sealed class Source {
    data class Xtream(val host: String, val user: String, val pass: String) : Source()
    data class M3u(val url: String) : Source()
}
